package core.network;

public class DBConnector {

	
	public void saveAufgabe(){
		
		//JDBC.SaveKruschtinDB(Configuration.DBIP, String qurey);
		
	}
	
}
