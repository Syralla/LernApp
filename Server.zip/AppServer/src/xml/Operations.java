package xml;

public enum Operations {

	ADD,SUB,MUL,DIV;
	
}
