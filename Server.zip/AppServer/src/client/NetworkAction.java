package client;

import java.io.PrintWriter;

public interface NetworkAction {

	public void performAction(PrintWriter pw);
		
}
